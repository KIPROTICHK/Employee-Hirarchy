using EmployeesClassLibrary;
using System;
using System.IO;
using Xunit;

namespace UnitTestEmployees
{
    public class UnitTest1
    {
        //test if all salaries are valid in text file 1
        [Fact]
        public void TestValidSalaries()
        {
            var lines = File.ReadAllLines("../../../ListofEmployees1.txt");
            Employees employees = new Employees(lines);
            Assert.Equal(3300, employees.SalaryBudget("Employee1"));
            Assert.Equal(1000, employees.SalaryBudget("Employee2"));

        }
        [Fact]
        public void TestEmployees()
        {
            var lines = File.ReadAllLines("../../../ListofEmployees1.txt");
            Employees employees = new Employees(lines);
            Assert.Equal(3300, employees.SalaryBudget("Employee1"));
            Assert.Equal(1000, employees.SalaryBudget("Employee2"));

        }

        [Fact]
        public void TestDoubleLink()
        {
            var lines = File.ReadAllLines("../../../ListofEmployees2.txt");
            Employees employees = new Employees(lines);
            Assert.Equal(3300, employees.SalaryBudget("Employee1"));
            Assert.Equal(1000, employees.SalaryBudget("Employee2"));

        }
        //checking salaries of employees in text file 3
        [Fact]
        public void Test3()
        {
            var lines = File.ReadAllLines("../../../ListofEmployees3.txt");
            Employees employees = new Employees(lines);
            Assert.Equal(3800, employees.SalaryBudget("Employee1"));
            Assert.Equal(1800, employees.SalaryBudget("Employee2"));
            Assert.Equal(500, employees.SalaryBudget("Employee3"));

        }

        //test salary of Employee 4, should be 0 be3 of invalid chars
        [Fact]
        public void Test4()
        {
            var lines = File.ReadAllLines("../../../ListofEmployees4.txt");
            Employees employees = new Employees(lines);
            Assert.Equal(2800, employees.SalaryBudget("Employee1"));
            Assert.Equal(800, employees.SalaryBudget("Employee2"));
            Assert.Equal(500, employees.SalaryBudget("Employee3"));
            Assert.Equal(0, employees.SalaryBudget("Employee4"));

        }
    }
}
